package org.jetbrains.plugins.template.services

import com.intellij.ide.AppLifecycleListener
import com.intellij.openapi.project.Project
import com.intellij.openapi.startup.StartupActivity
import com.intellij.openapi.actionSystem.ActionManager
import com.intellij.notification.NotificationGroupManager
import com.intellij.notification.NotificationType
import com.intellij.openapi.application.invokeLater
import com.intellij.openapi.project.getOpenedProjects
import com.intellij.openapi.startup.ProjectActivity
import com.jetbrains.rd.util.string.print
import org.jetbrains.plugins.template.startup.AddCopyButtonActivity

class ErrorCollectorProjectActivity : StartupActivity {


    override fun runActivity(project: Project) {
        try {
            val actionManager = ActionManager.getInstance()
            AddCopyButtonActivity().initializePluginConfiguration(project)


            val action = actionManager.getAction("ErrorCollector.CopyAllErrors")


            if (action != null) {
                NotificationGroupManager.getInstance()
                    .getNotificationGroup("Error Collector")
                    .createNotification(
                        "Error Collector plugin ready",
                        NotificationType.INFORMATION
                    )
                    .notify(project)
            }
        } catch (e: Exception) {
            // Silent fail
        }    }

}
