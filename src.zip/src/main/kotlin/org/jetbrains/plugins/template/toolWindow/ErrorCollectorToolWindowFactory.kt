// src/main/kotlin/org/jetbrains/plugins/template/toolWindow/ErrorCollectorToolWindowFactory.kt
package org.jetbrains.plugins.template.toolWindow

import com.intellij.openapi.project.Project
import com.intellij.openapi.ui.Messages
import com.intellij.openapi.wm.ToolWindow
import com.intellij.openapi.wm.ToolWindowFactory
import com.intellij.ui.components.JBPanel
import com.intellij.ui.content.ContentFactory
import org.jetbrains.plugins.template.services.ErrorCollectorService
import org.jetbrains.plugins.template.startup.AddCopyButtonActivity
import java.awt.BorderLayout
import java.util.*
import javax.swing.JButton

class ErrorCollectorToolWindowFactory : ToolWindowFactory {

    override fun createToolWindowContent(project: Project, toolWindow: ToolWindow) {

        val panel = JBPanel<JBPanel<*>>(BorderLayout())

        val copyButton = JButton("📋 Copy All Errors").apply {
            addActionListener {
                val service = project.getService(ErrorCollectorService::class.java)
                val errors = service.collectAllErrors()
                if (errors.isEmpty()) {
                    Messages.showInfoMessage(project, "No errors or warnings found.", "Error Collector")
                } else {
                    val formatted = service.formatErrorsForAI(errors)

                    service.copyToClipboard(formatted)
                    Messages.showInfoMessage(project, "✅ Copied ${errors.size} issues!", "Error Collector")
                }
            }
        }
        panel.add(copyButton, BorderLayout.CENTER)

        val content = ContentFactory.getInstance().createContent(panel, "Copy All", false)
        toolWindow.contentManager.addContent(content)
    }

    override fun shouldBeAvailable(project: Project) = true

}

