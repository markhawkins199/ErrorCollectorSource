// src/main/kotlin/org/jetbrains/plugins/template/services/ErrorCollectorService.kt
package org.jetbrains.plugins.template.services

import com.intellij.codeInsight.daemon.impl.DaemonCodeAnalyzerImpl
import com.intellij.codeInsight.daemon.impl.HighlightInfo
import com.intellij.lang.annotation.HighlightSeverity
import com.intellij.openapi.components.Service
import com.intellij.openapi.fileEditor.FileDocumentManager
import com.intellij.openapi.fileEditor.FileEditorManager
import com.intellij.openapi.project.Project
import com.intellij.openapi.util.TextRange
import com.intellij.psi.PsiManager
import org.jetbrains.plugins.template.startup.AddCopyButtonActivity
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection
import java.util.*

@Service(Service.Level.PROJECT)
class ErrorCollectorService(private val project: Project) {


    data class ErrorInfo(
        val file: String,
        val line: Int,
        val column: Int,
        val severity: String,
        val message: String,
        val code: String?
    )

    fun collectAllErrors(): List<ErrorInfo> {
        val errors = mutableListOf<ErrorInfo>()
        val fileEditorManager = FileEditorManager.getInstance(project)

        for (file in fileEditorManager.openFiles) {
            if (file.isValid && !file.isDirectory) {
                collectErrorsFromFile(file, errors)
            }
        }

        // Sort by file name, then line
        return errors.sortedWith(compareBy({ it.file }, { it.line }))
    }

    private fun collectErrorsFromFile(
        file: com.intellij.openapi.vfs.VirtualFile,
        errors: MutableList<ErrorInfo>
    ) {
        try {
            val psiFile = PsiManager.getInstance(project).findFile(file) ?: return
            val document = FileDocumentManager.getInstance().getDocument(file) ?: return

            val highlights: List<HighlightInfo> = DaemonCodeAnalyzerImpl.getHighlights(document, null, project)

            for (highlight in highlights) {
                val severity: HighlightSeverity = highlight.severity
                if (severity != HighlightSeverity.ERROR && severity != HighlightSeverity.WARNING) continue

                val startOffset = highlight.startOffset
                val lineNumber = document.getLineNumber(startOffset) + 1
                val column = startOffset - document.getLineStartOffset(lineNumber - 1) + 1

                val lineStart = document.getLineStartOffset(lineNumber - 1)
                val lineEnd = document.getLineEndOffset(lineNumber - 1)
                val codeLine = document.getText(TextRange(lineStart, lineEnd)).trim()

                errors.add(
                    ErrorInfo(
                        file = file.presentableName,
                        line = lineNumber,
                        column = column,
                        severity = if (severity == HighlightSeverity.ERROR) "ERROR" else "WARNING",
                        message = highlight.description ?: "Unknown error",
                        code = codeLine
                    )
                )
            }
        } catch (_: Exception) {
            // ignore files that can't be analysed
        }
    }

    fun formatErrorsForAI(errors: List<ErrorInfo>): String {
        if (errors.isEmpty()) return "✅ No errors or warnings found."

        val sb = StringBuilder()
        sb.appendLine("=== Code Errors Summary ===")
        sb.appendLine("Total: ${errors.size} issues found")
        sb.appendLine()

        errors.groupBy { it.file }.forEach { (file, fileErrors) ->
            sb.appendLine("📁 $file")
            sb.appendLine("-".repeat(50))
            fileErrors.forEachIndexed { index, error ->
                sb.appendLine("${index + 1}. [${error.severity}] Line ${error.line}:${error.column}")
                sb.appendLine("   Message: ${error.message}")
                if (!error.code.isNullOrBlank()) {
                    sb.appendLine("   Code: ${error.code}")
                }
                sb.appendLine()
            }
        }

        return sb.toString()
    }

    fun copyToClipboard(text: String) {
        val clipboard = Toolkit.getDefaultToolkit().systemClipboard
        clipboard.setContents(StringSelection(text), null)
    }
}