// src/main/kotlin/org/jetbrains/plugins/template/startup/ToolWindowCopyActivity.kt
package org.jetbrains.plugins.template.startup

import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.project.Project
import com.intellij.openapi.startup.ProjectActivity
import com.intellij.openapi.ui.Messages
import com.intellij.openapi.wm.ToolWindowManager
import org.jetbrains.plugins.template.services.ErrorCollectorService

class ToolWindowCopyActivity : ProjectActivity {

    override suspend fun execute(project: Project) {
        ApplicationManager.getApplication().invokeLater {
            val toolWindow = ToolWindowManager.getInstance(project).getToolWindow("Error Collector") ?: return@invokeLater

            // Listen for when the tool window is shown (stripe button clicked)
            toolWindow.contentManager.addContentManagerListener(object : com.intellij.ui.content.ContentManagerListener {
                override fun contentAdded(event: com.intellij.ui.content.ContentManagerEvent) {
                    // The tool window was opened -> perform copy immediately
                    ApplicationManager.getApplication().invokeLater {
                        try {
                            val service = project.getService(ErrorCollectorService::class.java)
                            val errors = service.collectAllErrors()
                            if (errors.isEmpty()) {
                                Messages.showInfoMessage(project, "No errors or warnings found.", "Error Collector")
                            } else {
                                val formatted = service.formatErrorsForAI(errors)
                                service.copyToClipboard(formatted)
                                Messages.showInfoMessage(project, "✅ Copied ${errors.size} issues!", "Error Collector")
                            }
                        } catch (ex: Exception) {
                            Messages.showErrorDialog(project, "Error: ${ex.message}", "Error Collector")
                        } finally {
                            // Immediately close the tool window (no panel visible)
                            toolWindow.hide(null)
                        }
                    }
                }
            })
        }
    }
}