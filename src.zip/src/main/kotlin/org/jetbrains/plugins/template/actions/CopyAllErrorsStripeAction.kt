// src/main/kotlin/org/jetbrains/plugins/template/actions/CopyAllErrorsStripeAction.kt
package org.jetbrains.plugins.template.actions

import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.project.DumbAware
import com.intellij.openapi.project.Project
import com.intellij.openapi.wm.ToolWindowManager
import com.intellij.openapi.wm.impl.InternalDecorator
import org.jetbrains.plugins.template.services.ErrorCollectorService
import javax.swing.Icon

class CopyAllErrorsStripeAction : com.intellij.openapi.actionSystem.AnAction(), DumbAware {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return
        val service = project.getService(ErrorCollectorService::class.java)
        val errors = service.collectAllErrors()
        val formatted = if (errors.isEmpty()) {
            "✅ No errors or warnings found."
        } else {
            service.formatErrorsForAI(errors)
        }
        service.copyToClipboard(formatted)
    }
}