package org.jetbrains.plugins.template.actions

import com.intellij.codeInsight.daemon.impl.DaemonCodeAnalyzerImpl
import com.intellij.lang.annotation.HighlightSeverity
import com.intellij.notification.NotificationGroupManager
import com.intellij.notification.NotificationType
import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.fileEditor.FileDocumentManager
import com.intellij.openapi.fileEditor.FileEditorManager
import com.intellij.openapi.project.DumbAware
import com.intellij.openapi.project.Project
import com.intellij.openapi.util.TextRange
import com.intellij.psi.PsiManager
import org.jetbrains.plugins.template.startup.AddCopyButtonActivity
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection
import java.util.*

class CopyAllErrorsAction : AnAction(), DumbAware {

    override fun actionPerformed(e: AnActionEvent) {
        val project = e.project ?: return

        ApplicationManager.getApplication().invokeLater {
            try {
                val allIssues = collectAllIssues(project)

                if (allIssues.isEmpty()) {
                    showNotification(project, "✅ No errors or warnings found in open files.")
                    return@invokeLater
                }

                // Separate severe (compilation-blocking) errors from everything else
                val severeErrors = allIssues.filter { it.severity == "SEVERE" }
                val otherIssues = allIssues.filter { it.severity == "WARNING" }

                val finalList: List<ErrorInfo>
                val label: String

                if (severeErrors.isNotEmpty()) {
                    finalList = severeErrors
                    label = "severe errors"
                } else if (otherIssues.isNotEmpty()) {
                    finalList = otherIssues
                    label = "warnings"
                } else {
                    showNotification(project, "✅ No errors or warnings found in open files.")
                    return@invokeLater
                }

                val formatted = formatErrors(finalList)
                copyToClipboard(formatted)
                showNotification(project, "✅ Copied ${finalList.size} $label to clipboard!")
            } catch (ex: Exception) {
                showNotification(project, "❌ Failed: ${ex.message}")
            }
        }
    }

    private fun collectAllIssues(project: Project): List<ErrorInfo> {
        val issues = mutableListOf<ErrorInfo>()
        val fileEditorManager = FileEditorManager.getInstance(project)

        for (file in fileEditorManager.openFiles) {
            if (!file.isValid || file.isDirectory) continue
            collectFromFile(project, file, issues)
        }

        return issues.sortedWith(compareBy({ it.file }, { it.line }))
    }

    private fun collectFromFile(
        project: Project,
        file: com.intellij.openapi.vfs.VirtualFile,
        issues: MutableList<ErrorInfo>
    ) {
        try {
            val psiFile = PsiManager.getInstance(project).findFile(file) ?: return
            val document = FileDocumentManager.getInstance().getDocument(file) ?: return
            val highlights: List<com.intellij.codeInsight.daemon.impl.HighlightInfo> =
                DaemonCodeAnalyzerImpl.getHighlights(document, null, project)

            for (highlight in highlights) {
                val severity = highlight.severity
                val description = highlight.description

                // Skip highlights with no description — they're usually import markers or non-issue highlights
                if (description.isNullOrBlank()) continue

                // Determine category
                val severityCategory = when (severity) {
                    HighlightSeverity.ERROR -> {
                        if (isCompilationBlocking(description)) "SEVERE" else null
                    }
                    HighlightSeverity.WARNING -> "WARNING"
                    else -> null // skip INFO, WEAK_WARNING, etc.
                }

                if (severityCategory == null) continue

                val startOffset = highlight.startOffset
                val lineNumber = document.getLineNumber(startOffset) + 1
                val column = startOffset - document.getLineStartOffset(lineNumber - 1) + 1
                val lineStart = document.getLineStartOffset(lineNumber - 1)
                val lineEnd = document.getLineEndOffset(lineNumber - 1)
                val codeLine = document.getText(TextRange(lineStart, lineEnd)).trim()

                issues.add(
                    ErrorInfo(
                        file = file.presentableName,
                        line = lineNumber,
                        column = column,
                        severity = severityCategory,
                        message = description,
                        code = codeLine
                    )
                )
            }
        } catch (_: Exception) {
            // skip files that can't be analyzed
        }
    }

    /**
     * Returns true if the error description indicates a compilation-blocking problem.
     */
    private fun isCompilationBlocking(description: String): Boolean {
        val desc = description.lowercase(Locale.ROOT)

        val severePatterns = listOf(
            "cannot find symbol",
            "cannot resolve symbol",
            "cannot resolve",
            "unclosed",
            "expected",
            "not a statement",
            "illegal start",
            "incompatible types",
            "duplicate",
            "missing return",
            "unreachable statement",
            "variable might not have been initialized",
            "already defined",
            "does not override",
            "abstract method",
            "does not implement",
            "cyclic inheritance",
            "class not found",
            "package not found",
            "unexpected token",
            "cannot be applied to",
            "operator cannot be applied",
            "cannot assign",
            "cannot dereference",
            "cannot inherit",
            "cannot implement",
            "cannot extend",
            "cannot throw",
            "cannot return",
            "cannot be instantiated",
            "illegal character",
            "illegal expression",
            "illegal modifier",
            "illegal start of",
            "illegal underscore",
            "illegal static",
            "illegal forward reference",
            "syntax error",
            "type mismatch",
            "undefined",
            "unknown",
            "unterminated",
            "wrong number of type arguments",
            "not found",
            "is not abstract",
            "exception never thrown",
            "unhandled exception"
        )

        for (pattern in severePatterns) {
            if (desc.contains(pattern)) {
                return true
            }
        }

        // If it's marked as ERROR severity and doesn't match any pattern,
        // it's still likely a compilation error — treat as severe
        return true
    }

    private fun formatErrors(errors: List<ErrorInfo>): String {
        val sb = StringBuilder()
        sb.appendLine("=== Code Errors Summary ===")
        sb.appendLine("Total: ${errors.size} issues found")
        sb.appendLine()

        errors.groupBy { it.file }.forEach { (file, fileErrors) ->
            sb.appendLine("📁 $file")
            sb.appendLine("-".repeat(50))
            fileErrors.forEachIndexed { index, error ->
                sb.appendLine("${index + 1}. [${error.severity}] Line ${error.line}:${error.column}")
                sb.appendLine("   Message: ${error.message}")
                if (!error.code.isNullOrBlank()) {
                    sb.appendLine("   Code: ${error.code}")
                }
                sb.appendLine()
            }
        }

        return sb.toString()
    }

    private fun copyToClipboard(text: String) {
        val clipboard = Toolkit.getDefaultToolkit().systemClipboard
        clipboard.setContents(StringSelection(text), null)
    }

    private fun showNotification(project: Project, message: String) {
        NotificationGroupManager.getInstance()
            .getNotificationGroup("Error Collector")
            .createNotification(message, NotificationType.INFORMATION)
            .notify(project)
    }

    override fun update(e: AnActionEvent) {
        e.presentation.isEnabled = e.project != null
    }

    data class ErrorInfo(
        val file: String,
        val line: Int,
        val column: Int,
        val severity: String,
        val message: String,
        val code: String?
    )
}